import reflex as rx
from ..state import GuildState
from ..components.sidebar import page_shell, with_sidebar

@rx.page(route="/guilds", on_load=GuildState.load_guilds)
def guilds_page() -> rx.Component:
    return with_sidebar(
        page_shell(
            "服务器管理",
            rx.table.root(
                rx.table.header(
                    rx.table.row(
                        rx.table.column_header_cell("服务器名称"),
                        rx.table.column_header_cell("服务器 ID"),
                        rx.table.column_header_cell("成员数"),
                        rx.table.column_header_cell("欢迎词配置 (示例)"),
                    )
                ),
                rx.table.body(
                    rx.foreach(
                        GuildState.guilds,
                        lambda g: rx.table.row(
                            rx.table.cell(g.guild_name),
                            rx.table.cell(g.guild_id),
                            rx.table.cell(g.member_count),
                            rx.table.cell(g.configs.get("welcome_msg", "未设置")),
                        )
                    )
                ),
                width="100%",
            ),
        )
    )