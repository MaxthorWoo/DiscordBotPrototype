"""侧边栏导航组件 — 路由高亮 + 悬浮效果 + 底部图标栏 + 设置弹窗"""
import reflex as rx
from ..state.bot_state import BotState


# ── 导航项配置 ───────────────────────────────────────────
NAV_ITEMS = [
    ("home",            "首页",      "/"),
    ("server",          "服务器管理", "/guilds"),
    ("shield-alert",    "陷阱日志",  "/trap"),
    ("gift",            "礼包码管理", "/giftcodes"),
    ("message-square",  "消息配置",  "/messages"),
    ("radio",           "消息广播",  "/broadcast"),
]


# ── 导航状态：追踪当前路由 ───────────────────────────────
class NavState(rx.State):
    """侧边栏导航状态，提供当前路径用于高亮判断"""

    @rx.var
    def current_path(self) -> str:
        url = self.router.url
        if not url:
            return "/"
        return url.rstrip("/") or "/"


# ── 导航链接 ─────────────────────────────────────────────
# 内联 CSS 定义导航项样式（避免 Rx 动态 prop 不生效）
NAV_CSS = """
.side-nav-link {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    width: 100%;
    padding: 0.5rem 0.75rem;
    border-radius: 9999px;
    background: transparent;
    color: var(--gray-11);
    font-size: 0.875rem;
    font-weight: 400;
    transition: all 0.2s ease;
    cursor: pointer;
}
.side-nav-link:hover {
    background: var(--gray-3);
}
.side-nav-link--active {
    background: var(--plum-4) !important;
    color: var(--plum-11) !important;
    font-weight: 600 !important;
    box-shadow: 0 0 0 2px var(--plum-8) !important;
}
"""


def _nav_link(icon: str, label: str, href: str) -> rx.Component:
    """单个导航项 — class 驱动激活态，硬编码 icon 避免 Var 类型问题"""
    return rx.link(
        rx.hstack(
            rx.icon(icon, size=18),
            rx.text(label),
            class_name=rx.cond(
                NavState.current_path == href,
                "side-nav-link side-nav-link--active",
                "side-nav-link",
            ),
        ),
        href=href,
        width="100%",
        text_decoration="none",
    )


def nav_section() -> rx.Component:
    """导航菜单区块 — 硬编码 6 项，每项 icon 为字面量字符串"""
    return rx.vstack(
        _nav_link("home",           "首页",      "/"),
        _nav_link("server",         "服务器管理", "/guilds"),
        _nav_link("shield-alert",   "陷阱日志",  "/trap"),
        _nav_link("gift",           "礼包码管理", "/giftcodes"),
        _nav_link("message-square", "消息配置",  "/messages"),
        _nav_link("radio",          "消息广播",  "/broadcast"),
        spacing="1",
        width="100%",
        padding_x="2",
    )


# ── Bot 设置弹窗 ─────────────────────────────────────────
def bot_settings_dialog() -> rx.Component:
    """设置 Bot 的弹窗表单"""
    return rx.dialog.root(
        rx.dialog.content(
            rx.dialog.title("Bot 设置"),
            rx.dialog.description(
                "在此配置你的 Discord Bot，绑定后即可使用平台的全部功能",
                size="2",
                margin_bottom="4",
            ),
            # 表单
            rx.vstack(
                # Bot 名称
                rx.vstack(
                    rx.text("Bot 名称", font_weight="bold", font_size="sm"),
                    rx.input(
                        placeholder="例如：我的交易Bot",
                        value=BotState._bot_name_input,
                        on_change=BotState.set_bot_name,
                        width="100%",
                    ),
                    spacing="1",
                    width="100%",
                ),
                # Bot Token
                rx.vstack(
                    rx.text("Bot Token", font_weight="bold", font_size="sm"),
                    rx.text(
                        "在 Discord Developer Portal → Bot 页面获取",
                        font_size="xs",
                        color="gray",
                    ),
                    rx.input(
                        placeholder="输入你的 Bot Token...",
                        value=BotState._bot_token_input,
                        on_change=BotState.set_bot_token,
                        type="password",
                        width="100%",
                    ),
                    spacing="1",
                    width="100%",
                ),
                # 按钮
                rx.hstack(
                    rx.button(
                        "保存设置",
                        color_scheme="green",
                        cursor="pointer",
                        on_click=BotState.save_bot,
                    ),
                    rx.button(
                        "测试连接",
                        variant="outline",
                        cursor="pointer",
                        on_click=BotState.test_connection,
                    ),
                    rx.dialog.close(
                        rx.button("取消", variant="soft", color_scheme="gray"),
                    ),
                    spacing="2",
                ),
                # 测试结果
                rx.cond(
                    BotState.test_result == "testing",
                    rx.callout("正在测试连接...", color_scheme="gray", width="100%"),
                ),
                rx.cond(
                    BotState.test_result == "success",
                    rx.callout("连接成功！Token 有效", color_scheme="green", width="100%"),
                ),
                rx.cond(
                    BotState.test_result == "failed",
                    rx.callout(BotState.test_message, color_scheme="red", width="100%"),
                ),
                spacing="3",
                width="100%",
            ),
            max_width="460px",
        ),
        open=BotState.show_settings,
        on_open_change=BotState.handle_settings_change,
    )


# ── 底部栏：Bot 状态 + 设置 + 主题 ───────────────────────
def sidebar_bottom() -> rx.Component:
    """侧边栏底部：Bot 名称 + 在线指示 + 设置齿轮 + 日夜切换"""
    return rx.vstack(
        # Bot 状态指示
        rx.cond(
            BotState.sidebar_bot_name != "",
            rx.hstack(
                rx.box(
                    width="8px",
                    height="8px",
                    border_radius="50%",
                    background=rx.cond(
                        BotState.is_active,
                        "var(--green-9)",
                        "var(--gray-8)",
                    ),
                    flex_shrink="0",
                ),
                rx.text(
                    BotState.sidebar_bot_name,
                    font_size="xs",
                    color="var(--gray-11)",
                    overflow="hidden",
                    text_overflow="ellipsis",
                    white_space="nowrap",
                ),
                spacing="2",
                align="center",
                width="100%",
            ),
            rx.text(
                "未配置 Bot",
                font_size="xs",
                color="var(--gray-9)",
            ),
        ),
        # 图标按钮：设置 + 日夜模式
        rx.hstack(
            rx.icon_button(
                rx.icon("settings", size=18),
                on_click=BotState.open_settings,
                variant="ghost",
                color_scheme="gray",
                size="2",
                cursor="pointer",
            ),
            rx.spacer(),
            rx.color_mode.button(
                size="1",
                variant="ghost",
                color_scheme="gray",
                cursor="pointer",
            ),
            spacing="2",
            justify="center",
            width="100%",
        ),
        spacing="3",
        width="100%",
        padding="2",
        # padding_top="3",
        # padding_x="1",
        border_top="1px solid var(--gray-5)",
    )


# ── 侧边栏主体 ───────────────────────────────────────────
def sidebar() -> rx.Component:
    """全局侧边栏导航 — 上方品牌 + 中间菜单 + 下方工具栏"""
    return rx.box(
        # 注入自定义 CSS
        rx.html(f"<style>{NAV_CSS}</style>"),
        rx.vstack(
            # Logo / 品牌
            rx.hstack(
                rx.icon("mountain", size=22, color="var(--plum-9)"),
                rx.heading("DiscordBot", size="5", color="var(--plum-11)"),
                spacing="2",
                align="center",
            ),
            rx.divider(size="4"),
            # 导航菜单
            nav_section(),
            # 调试：显示当前路由路径（确认 NavState 是否跟踪到导航变化）
            rx.text(
                NavState.current_path,
                font_size="10px",
                color="var(--gray-8)",
                padding_x="2",
            ),
            # 弹性空白
            rx.box(flex="1"),
            # 底部工具栏
            sidebar_bottom(),
            # 容器样式
            spacing="3",
            width="220px",
            height="100vh",
            padding="1em",
            border_right="1px solid var(--gray-5)",
            background="var(--gray-1)",
            position="fixed",
            left="0",
            top="0",
        ),
    )


# ── 统一页面外壳 ─────────────────────────────────────────
def page_shell(title: str, subtitle: str = "", *children: rx.Component) -> rx.Component:
    """统一页面布局外壳 — 标题 + 分隔线 + 内容，标准化间距

    Args:
        title: 页面标题
        *children: 页面主体内容（多个组件）
        subtitle: 可选的副标题
    """
    return rx.box(
        rx.vstack(
            rx.hstack(
                rx.vstack(
                    rx.heading(title, size="6"),
                    rx.cond(
                        subtitle != "",
                        rx.text(subtitle, color="gray", font_size="sm"),
                    ),
                    spacing="1",
                ),
                width="100%",
            ),
            rx.divider(size="4"),
            *children,
            spacing="4",
            width="100%",
        ),
        padding="2em",
        max_width="1200px",
        width="100%",
    )


# ── 页面布局包裹器 ───────────────────────────────────────
def with_sidebar(content: rx.Component) -> rx.Component:
    """在页面内容外包裹侧边栏布局，含全局弹窗"""
    return rx.hstack(
        sidebar(),
        rx.box(
            content,
            flex="1",
            margin_left="220px",
            background="var(--gray-1)",
        ),
        # 全局飘字
        rx.cond(
            BotState.save_toast != "",
            rx.box(
                rx.text(BotState.save_toast, font_size="sm", color="white"),
                position="fixed",
                top="1em",
                right="1em",
                z_index="9999",
                padding="0.6em 1.2em",
                border_radius="md",
                background="var(--green-9)",
                box_shadow="0 2px 8px rgba(0,0,0,0.2)",
            ),
        ),
        # 设置弹窗（全局存在）
        bot_settings_dialog(),
        width="100%",
    )
