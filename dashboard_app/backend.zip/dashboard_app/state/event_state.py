import reflex as rx
from shared_lib import crud

class EventState(rx.State):
    """事件日志状态"""
    events: list[dict] = []

    def load_events(self):
        records = crud.get_recent_events(limit=10)
        self.events = [
            {"source": r.event_source, "type": r.event_type, "msg": r.message, "time": r.created_at}
            for r in records
        ]
        crud.add_system_event(source="web", event_type="page_load", message="后台首页被访问")