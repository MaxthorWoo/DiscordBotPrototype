"""机器人消息模板配置 State"""
import asyncio
import reflex as rx
from shared_lib import crud
from .bot_state import BotState


class MessageState(rx.State):
    """管理机器人所有可自定义的消息模板"""

    messages: list[dict] = []
    editing_key: str = ""       # 当前选中/编辑的消息 key
    edit_value: str = ""        # 编辑框中的文本
    toast_text: str = ""        # 飘字提示文字
    is_loaded: bool = False

    _selected_variables: str = ""  # 当前选中消息的可用变量（内部用，不参与序列化到前端）

    async def load_data(self):
        """加载所有消息模板"""
        bot_state = await self.get_state(BotState)
        bot_id = bot_state.current_bot_id
        self.messages = crud.get_all_bot_messages(bot_id)
        self.is_loaded = True

    def begin_edit(self, key: str):
        """点击左侧列表项，右侧打开编辑面板"""
        self.toast_text = ""  # 切换时清除旧飘字
        for m in self.messages:
            if m["message_key"] == key:
                self.editing_key = key
                self.edit_value = m["message_text"]
                self._selected_variables = m.get("variables", "")
                break

    def cancel_edit(self):
        """取消选择"""
        self.editing_key = ""
        self.edit_value = ""
        self._selected_variables = ""

    def set_edit_value(self, value: str):
        self.edit_value = value

    async def save_message(self):
        """保存当前编辑的消息，编辑面板保持不变"""
        if not self.editing_key:
            return

        bot_state = await self.get_state(BotState)
        bot_id = bot_state.current_bot_id

        if crud.update_bot_message(bot_id, self.editing_key, self.edit_value):
            await self.load_data()
            self.toast_text = f"「{self.editing_key}」保存成功"
        else:
            self.toast_text = "保存失败，请稍后重试"

        # 2 秒后自动消失
        yield
        await asyncio.sleep(2)
        self.toast_text = ""

    async def reset_message(self, key: str):
        """重置某条消息为默认值"""
        bot_state = await self.get_state(BotState)
        bot_id = bot_state.current_bot_id
        default = crud.reset_bot_message(bot_id, key)
        if default is not None:
            self.edit_value = default
            await self.load_data()
            self.toast_text = f"「{key}」已重置为默认值"
        else:
            self.toast_text = "重置失败"

        yield
        await asyncio.sleep(2)
        self.toast_text = ""
