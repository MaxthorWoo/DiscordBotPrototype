import reflex as rx
from shared_lib import crud
from pydantic import BaseModel
from .bot_state import BotState

class GuildInfo(BaseModel):
    guild_id: str
    guild_name: str
    member_count: int
    configs: dict

class GuildState(rx.State):
    guilds: list[GuildInfo] = []

    async def load_guilds(self):
        bot_state = await self.get_state(BotState)
        bot_id = bot_state.current_bot_id
        raw_data = crud.get_guilds_with_config(bot_id)
        self.guilds = [
            GuildInfo(
                guild_id=item["guild_id"],
                guild_name=item["guild_name"],
                member_count=item["member_count"],
                configs=item["configs"]
            )
            for item in raw_data
        ]